<div class="container-box cb-form-max-width align-center flex-1">
    <div class="cb-header">
        <div class="cb-title">Formulário</div>
    </div>
    <div class="cb-body">
        <form>
            <label>
                <div class="lbl">Nome</div>
                <input type="text">
            </label>

            <label>
                <div class="lbl">Data</div>
                <input type="date">
            </label>

            <label>
                <div class="lbl">Status</div>
                <select>
                    <option disabled selected style="display: none;">Selecione</option>
                    <option value="1">Aprovado</option>
                    <option value="2">Pendente</option>
                    <option value="3">Reprovado</option>
                    <option value="4">Em análise</option>
                </select>
            </label>
        </form>
    </div>
</div>
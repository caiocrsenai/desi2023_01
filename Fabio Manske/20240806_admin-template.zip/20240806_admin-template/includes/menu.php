<nav class="main-menu">
    <div class="main-menu-inside">
        <div class="title">Dashboard</div>
        <ul>
            <li>
                <a href="?page=inicial">
                    <i class="fa-solid fa-gauge"></i>
                    Inicial
                </a>
            </li>
            <li>
                <a href="?page=form">
                    <i class="fa-solid fa-gauge"></i>
                    Formulário
                </a>
            </li>
            <li>
                <a href="?page=usuarios">
                    <i class="fa-solid fa-gauge"></i>
                    Usuários
                </a>
            </li>
        </ul>
    </div>
</nav>